<template>
    <div class="py-12">
        <h1 class="text-2xl font-bold text-center">همه خدمات</h1>
        <div class="flex justify-center gap-x-6 mt-12">
            <Services/>
        </div>
    </div>
</template>